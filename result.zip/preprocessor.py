import numpy as np
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.preprocessing import StandardScaler
from sklearn.preprocessing import RobustScaler
class Preprocessor:
    def __init__(self, df):
        self.df = df.copy()

    def remove_outliers_zscore(self, threshold=3):
       numeric_cols = self.df.select_dtypes(include=[np.number]).columns
       numeric_cols = [col for col in numeric_cols if self.df[col].nunique() > 2]
       means = self.df[numeric_cols].mean()
       stds = self.df[numeric_cols].std()
       z_scores = np.abs((self.df[numeric_cols] - means) / stds)
       mask = (z_scores < threshold).all(axis=1)
       self.df = self.df[mask].reset_index(drop=True)

    def remove_high_missing(self, threshold=0.5):
        missing_ratio = self.df.isnull().mean()
        cols_to_drop = missing_ratio[missing_ratio > threshold].index
        self.df.drop(columns=cols_to_drop, inplace=True)

    def handle_missing_values(self):
        for col in self.df.columns:
            if self.df[col].dtype in [np.float64, np.int64]:
                self.df[col].fillna(self.df[col].median(), inplace=True)
            else:
                self.df[col].fillna(self.df[col].mode()[0], inplace=True)

    def label_encode(self):
        cat_cols = self.df.select_dtypes(include=['object', 'category', 'bool']).columns
        le = LabelEncoder()
        for col in cat_cols:
            self.df[col] = le.fit_transform(self.df[col])

    def scale_numeric(self, columns):
        scaler = RobustScaler()
        self.df[columns] = scaler.fit_transform(self.df[columns])

    def transform(self):
        self.remove_high_missing()
        self.handle_missing_values()
        self.label_encode()
        columns_to_scale = ['Age', 'Annual Income (k$)', 'Spending Score (1-100)']
        self.scale_numeric(columns_to_scale)
        self.remove_outliers_zscore()
        return self.df
